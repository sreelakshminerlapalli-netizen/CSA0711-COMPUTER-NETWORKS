"""Run ping to a host and print loss, min/avg/max RTT and jitter (mdev). Usage: python3 b1_ping_summary.py <host> [count]
Works with the Linux/macOS ping output format. Use the same script at three times of day and save the output."""
import re, subprocess, sys

def parse(text):
    loss = re.search(r"([\d.]+)% packet loss", text)
    rtt = re.search(r"= ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+) ms", text)
    if not (loss and rtt):
        raise ValueError("unrecognised ping output")
    mn, avg, mx, mdev = map(float, rtt.groups())
    return dict(loss=float(loss.group(1)), min=mn, avg=avg, max=mx, jitter=mdev)

if __name__ == "__main__":
    host = sys.argv[1]; count = sys.argv[2] if len(sys.argv) > 2 else "100"
    out = subprocess.run(["ping", "-c", count, "-i", "0.2", host], capture_output=True, text=True).stdout
    r = parse(out)
    print(f"{host}: loss {r['loss']:.1f} %  min {r['min']:.2f}  avg {r['avg']:.2f}  max {r['max']:.2f}  jitter(mdev) {r['jitter']:.2f} ms")
