"""A stateless packet filter: the first matching rule decides (like iptables)."""
RULES = [  # (action, protocol, destination port or None for any, source prefix or None)
    ("allow", "tcp", 443, None),
    ("allow", "tcp", 22, "10.1."),
    ("deny", "tcp", 22, None),
    ("allow", "udp", 53, None),
]
DEFAULT = "deny"

def decide(proto, port, src, rules=RULES):
    for action, p, dport, prefix in rules:
        # TODO 1 (completed): a rule matches when its protocol equals proto, its port is
        # None or equals port, and its prefix is None or src starts with it.
        if p == proto and (dport is None or dport == port) and (prefix is None or src.startswith(prefix)):
            return action
    return DEFAULT

packets = [("tcp", 443, "49.37.2.8"), ("tcp", 22, "10.1.4.20"),
           ("tcp", 22, "49.37.2.8"), ("udp", 53, "10.1.4.20"),
           ("tcp", 80, "49.37.2.8"), ("icmp", None, "49.37.2.8")]

print("--- Original order ---")
for pk in packets:
    print(f"{pk[0]:<5} {str(pk[1]):<5} from {pk[2]:<10} -> {decide(*pk)}")

swapped = [RULES[0], RULES[2], RULES[1], RULES[3]]   # rules 2 and 3 swapped
print("--- Rules 2 and 3 swapped ---")
for pk in packets:
    print(f"{pk[0]:<5} {str(pk[1]):<5} from {pk[2]:<10} -> {decide(*pk, rules=swapped)}")
