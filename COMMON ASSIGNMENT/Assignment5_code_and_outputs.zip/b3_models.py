"""Analytical models used for B3/B4 predictions (replace/compare with your own tc netem + iperf3 measurements)."""
import math

def mathis(mss_bytes, rtt_s, p, link_bps, window_bytes=None):
    """TCP Reno throughput bound: min(link, window/RTT, 1.22*MSS/(RTT*sqrt(p)))."""
    t = 1.22 * mss_bytes * 8 / (rtt_s * math.sqrt(p))
    t = min(t, link_bps)
    if window_bytes: t = min(t, window_bytes * 8 / rtt_s)
    return t

def emodel_mos(one_way_ms, loss_pct):
    """Simplified ITU-T G.107 E-model for G.711 with packet-loss concealment."""
    d = one_way_ms
    Id = 0.024 * d + (0.11 * (d - 177.3) if d > 177.3 else 0)
    Ie = 0 + (95 - 0) * loss_pct / (loss_pct + 25.1)             # Ie=0, Bpl=25.1, random loss
    R = 93.2 - Id - Ie
    R = max(0, min(100, R))
    mos = 1 + 0.035 * R + R * (R - 60) * (100 - R) * 7e-6
    return R, mos

print("## B3.1 TCP throughput (100 Mbps link, base RTT 20 ms, MSS 1460 B, window unlimited)")
print("delay_added_ms loss_pct rtt_ms tcp_mbps")
for dly in (0, 50, 150, 300):
    for lo in (0.01, 1, 5, 10):
        rtt = 0.020 + dly / 1000
        p = max(lo / 100, 1e-6)
        print(f"{dly:>3} {lo:>5} {rtt*1e3:>5.0f} {mathis(1460, rtt, p, 100e6)/1e6:8.3f}")
print("\n## B3.1 Voice quality (one-way delay = 10 ms base + netem added delay; netem on the sending side)")
print("added_ms loss_pct one_way_ms R MOS")
for dly in (0, 50, 150, 300):
    for lo in (0, 1, 5, 10):
        ow = 10 + dly
        R, m = emodel_mos(ow, lo)
        print(f"{dly:>3} {lo:>3} {ow:>4} {R:6.1f} {m:5.2f}")
print("\n## B3.2 Window size, 100 Mbps link, RTT 150 ms")
rtt = 0.150; link = 100e6
bdp = link * rtt / 8
print(f"BDP = {bdp/1e6:.3f} MB ({bdp/1024:.0f} KiB)")
for w in (64 * 1024, 256 * 1024, 1024 * 1024, 2 * 1024 * 1024, 4 * 1024 * 1024):
    thr = min(link, w * 8 / rtt)
    print(f"window {w/1024:>6.0f} KiB -> {thr/1e6:7.2f} Mbps ({thr/link*100:5.1f}% of link)")
print("\n## B3.3 Web server under flood (M/M/1, service rate 1000 req/s)")
mu = 1000.0
for label, lam in (("idle (normal load 40 req/s)", 40), ("flood 950 req/s + 40 normal, no limit", 990),
                   ("flood limited to 100 req/s + 40 normal", 140), ("flood 2000 req/s, no limit", 2040), ("flood 2000 req/s, limited to 100", 140)):
    if lam < mu:
        print(f"{label}: utilisation {lam/mu*100:.0f}% mean response {1000/(mu-lam):.2f} ms")
    else:
        print(f"{label}: overloaded (arrival {lam} > capacity {mu:.0f}); queue grows, requests time out")
print("\n## B4 prediction: intercontinental live class")
for city, km, ratio in (("India-Singapore", 2900, 1.6), ("India-Europe", 7400, 1.7), ("India-US west coast", 14000, 1.8)):
    floor = 2 * km * 1e3 / 2e8 * 1e3
    rtt = floor * ratio
    ow = rtt / 2 + 20   # + 20 ms codec/jitter buffer/last mile
    for lo in (0.5,):
        R, m = emodel_mos(ow, lo)
        print(f"{city}: floor RTT {floor:.0f} ms, expected RTT {rtt:.0f} ms, mouth-to-ear ~{ow:.0f} ms, MOS {m:.2f}")
print("Mathis TCP at 150-250 ms RTT, 0.1% loss:", [f"{mathis(1460, r/1000, 0.001, 100e6)/1e6:.1f} Mbps @ {r} ms" for r in (20, 150, 250)])
