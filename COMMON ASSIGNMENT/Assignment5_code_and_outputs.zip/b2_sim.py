"""Discrete-event simulation of one bottleneck link shared by VoIP calls and a greedy file download.
Schedulers: FIFO, strict priority (DiffServ EF) and weighted fair queuing (WFQ, self-clocked).
This is a supporting model; Packet Tracer / NS-3 runs are recorded separately in the repository."""
import heapq, random
from collections import deque

VOICE_B, DATA_B = 218, 1518          # Ethernet frame sizes in bytes: G.711 20 ms voice / file-transfer segment

def simulate(rate_bps, prop_ms=10.0, calls=10, bg_load=0.0, sched="fifo",
             wv=0.3, T=30.0, buf=60, seed=1):
    rnd = random.Random(seed)
    arr = []                                           # (time, cls, size, id)
    for c in range(calls):
        ph = rnd.uniform(0, 0.02)
        k = 0
        while ph + k * 0.02 < T:
            arr.append((ph + k * 0.02, "v", VOICE_B, c)); k += 1
    if bg_load > 0:
        gap = DATA_B * 8 / (bg_load * rate_bps)
        t = 0.0
        while t < T:                                   # Poisson arrivals: bursty like real TCP traffic
            arr.append((t, "d", DATA_B, -1)); t += rnd.expovariate(1.0 / gap)
    arr.sort()
    q = {"v": deque(), "d": deque()}; fifo = deque()
    last_tag = {"v": 0.0, "d": 0.0}; vt = 0.0
    w = {"v": wv, "d": 1 - wv}
    busy_until = None; cur = None; i = 0
    vdel = {c: [] for c in range(calls)}; vsent = 0; vlost = 0
    dbytes = 0; dsent = 0; dlost = 0
    def qlen(): return len(fifo) if sched == "fifo" else None
    def start(t):
        nonlocal busy_until, cur, vt
        pkt = None
        if sched == "fifo":
            if fifo: pkt = fifo.popleft()
        elif sched == "prio":
            if q["v"]: pkt = q["v"].popleft()
            elif q["d"]: pkt = q["d"].popleft()
        else:   # WFQ: smallest finish tag first
            heads = [(q[c][0][4], c) for c in ("v", "d") if q[c]]
            if heads:
                tag, c = min(heads); pkt = q[c].popleft(); vt = tag
        if pkt is None: cur = None; busy_until = None; return
        cur = pkt; busy_until = t + pkt[2] * 8 / rate_bps
    while i < len(arr) or cur is not None:
        na = arr[i][0] if i < len(arr) else float("inf")
        nd = busy_until if cur is not None else float("inf")
        if na <= nd:
            t, cls, size, cid = arr[i]; i += 1
            if cls == "v": vsent += 1
            else: dsent += 1
            tag = max(vt, last_tag[cls]) + size * 8 / w[cls]
            pkt = (t, cls, size, cid, tag)
            if sched == "fifo":
                ok = len(fifo) < buf
                if ok: fifo.append(pkt)
            else:
                ok = len(q[cls]) < buf
                if ok: q[cls].append(pkt); last_tag[cls] = tag
            if not ok:
                if cls == "v": vlost += 1
                else: dlost += 1
            if cur is None: start(t)
        else:
            t = nd; s, cls, size, cid, _ = cur
            if cls == "v": vdel[cid].append((t - s) * 1e3 + prop_ms)
            else: dbytes += size
            cur = None; start(t)
    alld = [x for c in vdel for x in vdel[c]]
    jit = []
    for c in vdel:
        d = vdel[c]; jit += [abs(d[k] - d[k - 1]) for k in range(1, len(d))]
    delay = sum(alld) / len(alld) if alld else float("nan")
    return dict(delay=delay, p99=sorted(alld)[int(0.99 * len(alld))] if alld else float("nan"),
                jitter=sum(jit) / len(jit) if jit else 0.0,
                loss=100 * vlost / vsent if vsent else 0.0,
                dl_mbps=dbytes * 8 / T / 1e6, dloss=100 * dlost / dsent if dsent else 0.0)

def row(label, **kw):
    r = simulate(**kw)
    print(f"{label} | delay {r['delay']:.1f} ms | p99 {r['p99']:.1f} ms | jitter {r['jitter']:.2f} ms | loss {r['loss']:.2f} % | download {r['dl_mbps']:.2f} Mbps")
    return r

if __name__ == "__main__":
    print("## E1 bandwidth sweep (10 calls, no background, 10 ms propagation)")
    for bw in (1e6, 2e6, 5e6, 10e6): row(f"{bw/1e6:g} Mbps", rate_bps=bw, calls=10)
    print("## E2 delay sweep (10 Mbps, 10 calls)")
    for pd in (10, 50, 150): row(f"prop {pd} ms", rate_bps=10e6, calls=10, prop_ms=pd)
    print("## E3 users sweep (2 Mbps, no background)")
    for n in (10, 20, 22, 23, 25): row(f"{n} calls", rate_bps=2e6, calls=n)
    print("## E4 background download, 10 Mbps, 20 calls, offered download 110 % of link")
    for s in ("fifo", "prio", "wfq"): row(s.upper(), rate_bps=10e6, calls=20, bg_load=1.1, sched=s)
    print("## E5 WFQ weight for voice (10 Mbps, 20 calls)")
    for wv in (0.1, 0.3, 0.5): row(f"WFQ voice weight {wv}", rate_bps=10e6, calls=20, bg_load=1.1, sched="wfq", wv=wv)
    print("## B4 doubling the users (10 Mbps)")
    for n in (20, 40):
        for s in ("fifo", "prio"): row(f"{n} calls {s.upper()}", rate_bps=10e6, calls=n, bg_load=1.1, sched=s)
    print("## E6 WFQ weight 0.3 versus strict priority when calls double (10 Mbps)")
    for n in (20, 40):
        row(f"{n} calls WFQ 0.3", rate_bps=10e6, calls=n, bg_load=1.1, sched="wfq", wv=0.3)
        row(f"{n} calls PRIO", rate_bps=10e6, calls=n, bg_load=1.1, sched="prio")
    print("## B4 overload check: 2 Mbps link, 22 and 44 calls with priority + download")
    for n in (22, 44): row(f"{n} calls PRIO", rate_bps=2e6, calls=n, bg_load=1.1, sched="prio")
