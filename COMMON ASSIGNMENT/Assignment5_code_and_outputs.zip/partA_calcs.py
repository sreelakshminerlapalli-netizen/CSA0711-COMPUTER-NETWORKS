"""Part A calculations (A1.1, A1.2, A3.1, A3.2, A5.1) with working."""
import math
print("== A1.1 Delay breakdown ==")
L = 1500 * 8; R = 100e6; links = 4; routers = 3
for rate, name in ((100e6, "100 Mbps"), (1e9, "1 Gbps")):
    tx = links * L / rate * 1e3
    prop = 2000e3 / 2e8 * 1e3
    q = routers * 0.5; p = routers * 0.1
    tot = tx + prop + q + p
    print(f"{name}: tx {tx:.3f} ms, prop {prop:.1f} ms, queue {q:.1f} ms, proc {p:.1f} ms, total {tot:.3f} ms, prop share {prop/tot*100:.1f}%")
print("\n== A1.2 BDP and 64 KB window ==")
bdp = 1e9 * 0.080
print(f"BDP = {bdp/1e6:.0f} Mbit = {bdp/8/1e6:.1f} MB")
thr = 64 * 1024 * 8 / 0.080
print(f"64 KB window throughput = {thr/1e6:.2f} Mbps ({thr/1e9*100:.2f}% of 1 Gbps)")
print("\n== A3.1 Distribution of 4 GB ==")
F = 4e9 * 8; N = 20; us = 100e6; d = 50e6; u = 20e6
cs = max(N * F / us, F / d)
p2p = max(F / us, F / d, N * F / (us + N * u))
print(f"client-server {cs:.0f} s = {cs/60:.1f} min; peer-to-peer {p2p:.0f} s = {p2p/60:.1f} min; ratio {cs/p2p:.1f}x")
print(f"  terms: N*F/us={N*F/us:.0f}, F/dmin={F/d:.0f}, F/us={F/us:.0f}, N*F/(us+sum ui)={N*F/(us+N*u):.0f}")
print(f"CDN warm cache {F/d:.0f} s; cold cache, 4 edges {max(4*F/us, F/d):.0f} s")
print("\n== A3.2 G.711 ==")
pps = 1000 / 20; payload = 64000 / pps / 8
ip_bytes = payload + 40; ip_bw = ip_bytes * 8 * pps
eth_bw = (ip_bytes + 18) * 8 * pps
print(f"{pps:.0f} pps, payload {payload:.0f} B, IP packet {ip_bytes:.0f} B, IP bandwidth {ip_bw/1e3:.0f} kbps, with Ethernet {eth_bw/1e3:.1f} kbps")
print(f"calls on 2 Mbps: {2e6/ip_bw:.1f} (IP level), {2e6/eth_bw:.1f} (Ethernet level)")
print("\n== A5.1 SYN flood ==")
print(f"rate = {1024/60:.2f} SYN/s; bandwidth at 60 B/SYN = {1024/60*60*8/1e3:.1f} kbps")
print(f"4 servers: {4*1024/60:.1f} SYN/s")
print("\n== Propagation floor RTT for distances (fibre 2e8 m/s) ==")
for city, km in (("Chennai-Bengaluru", 290), ("Chennai-Mumbai", 1030), ("Chennai-Singapore", 2900), ("Chennai-Frankfurt", 7400), ("Chennai-San Francisco", 14000)):
    print(f"{city}: {km} km -> one-way {km*1e3/2e8*1e3:.1f} ms, min RTT {2*km*1e3/2e8*1e3:.1f} ms")
print("\n== B1 alt: RTT/2 on asymmetric path ==")
pk = 1200 * 8
up = pk / 2e6 * 1e3 + 20 + 30   # ser + prop + upload queue
dn = pk / 50e6 * 1e3 + 20
rtt = up + dn
print(f"upload {up:.1f} ms, download {dn:.2f} ms, RTT {rtt:.1f} ms, RTT/2 {rtt/2:.1f} ms; error up {rtt/2-up:+.1f} ms ({(rtt/2-up)/up*100:+.0f}%), down {rtt/2-dn:+.1f} ms ({(rtt/2-dn)/dn*100:+.0f}%)")
